// script.js - Vayu VTOL Miniature Shop

// Product data
const products = [
    {
        id: 1,
        name: "V-22 Osprey",
        description: "Dual-engine tiltrotor military aircraft with exceptional hover capabilities.",
        price: 89.99,
        icon: "fas fa-helicopter",
        rating: 4.8,
        badge: "Best Seller"
    },
    {
        id: 2,
        name: "Harrier Jump Jet",
        description: "British-designed VTOL jet aircraft known for its vectoring nozzles.",
        price: 79.99,
        icon: "fas fa-fighter-jet",
        rating: 4.6,
        badge: null
    },
    {
        id: 3,
        name: "F-35B Lightning II",
        description: "Fifth-generation stealth fighter with STOVL capabilities.",
        price: 109.99,
        icon: "fas fa-plane",
        rating: 4.9,
        badge: "New"
    },
    {
        id: 4,
        name: "Bell Boeing Quad TiltRotor",
        description: "Conceptual four-rotor VTOL aircraft for heavy-lift missions.",
        price: 129.99,
        icon: "fas fa-helicopter",
        rating: 4.5,
        badge: null
    },
    {
        id: 5,
        name: "Skycar Prototype",
        description: "Futuristic personal VTOL vehicle for urban air mobility.",
        price: 149.99,
        icon: "fas fa-car",
        rating: 4.7,
        badge: "Limited Edition"
    },
    {
        id: 6,
        name: "Black Hawk VTOL",
        description: "Modified utility helicopter with enhanced hover stability.",
        price: 99.99,
        icon: "fas fa-helicopter",
        rating: 4.4,
        badge: null
    }
];

// Shopping cart state
let cart = [];
let cartTotal = 0;
let cartCount = 0;

// DOM Elements
const productsGrid = document.getElementById('productsGrid');
const cartSidebar = document.getElementById('cartSidebar');
const cartToggle = document.getElementById('cartToggle');
const closeCart = document.getElementById('closeCart');
const cartItems = document.getElementById('cartItems');
const cartCountElement = document.querySelector('.cart-count');
const cartSubtotalElement = document.querySelector('.cart-subtotal-amount');
const cartTotalElement = document.querySelector('.cart-total-amount');
const overlay = document.getElementById('overlay');
const shopNowButton = document.getElementById('shopNow');
const mobileMenuBtn = document.getElementById('mobileMenuBtn');
const navLinks = document.getElementById('navLinks');
const notification = document.getElementById('notification');

// Initialize the product grid
function initializeProducts() {
    productsGrid.innerHTML = '';
    
    products.forEach(product => {
        const productCard = document.createElement('div');
        productCard.className = 'product-card';
        
        let badgeHTML = '';
        if (product.badge) {
            badgeHTML = `<div class="product-badge">${product.badge}</div>`;
        }
        
        // Create star rating HTML
        let starsHTML = '';
        const fullStars = Math.floor(product.rating);
        const hasHalfStar = product.rating % 1 >= 0.5;
        
        for (let i = 0; i < 5; i++) {
            if (i < fullStars) {
                starsHTML += '<i class="fas fa-star"></i>';
            } else if (i === fullStars && hasHalfStar) {
                starsHTML += '<i class="fas fa-star-half-alt"></i>';
            } else {
                starsHTML += '<i class="far fa-star"></i>';
            }
        }
        
        productCard.innerHTML = `
            <div class="product-image">
                ${badgeHTML}
                <i class="${product.icon}"></i>
            </div>
            <div class="product-info">
                <h3 class="product-title">${product.name}</h3>
                <div class="product-rating">
                    ${starsHTML}
                    <span>${product.rating}</span>
                </div>
                <p class="product-description">${product.description}</p>
                <div class="product-price">$${product.price.toFixed(2)}</div>
                <button class="btn btn-secondary add-to-cart" data-id="${product.id}">Add to Cart</button>
            </div>
        `;
        
        productsGrid.appendChild(productCard);
    });
    
    // Add event listeners to all "Add to Cart" buttons
    document.querySelectorAll('.add-to-cart').forEach(button => {
        button.addEventListener('click', addToCart);
    });
}

// Show notification
function showNotification(message) {
    const notificationText = notification.querySelector('span');
    notificationText.textContent = message;
    notification.classList.add('show');
    
    setTimeout(() => {
        notification.classList.remove('show');
    }, 3000);
}

// Add product to cart
function addToCart(event) {
    const productId = parseInt(event.target.getAttribute('data-id'));
    const product = products.find(p => p.id === productId);
    
    // Check if product is already in cart
    const existingItem = cart.find(item => item.id === productId);
    
    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        cart.push({
            id: product.id,
            name: product.name,
            price: product.price,
            icon: product.icon,
            quantity: 1
        });
    }
    
    // Update cart display
    updateCart();
    
    // Show cart sidebar
    cartSidebar.classList.add('open');
    overlay.classList.add('active');
    
    // Show notification
    showNotification(`${product.name} added to cart!`);
    
    // Visual feedback on button
    event.target.textContent = 'Added!';
    event.target.classList.add('btn-primary');
    event.target.classList.remove('btn-secondary');
    
    setTimeout(() => {
        event.target.textContent = 'Add to Cart';
        event.target.classList.remove('btn-primary');
        event.target.classList.add('btn-secondary');
    }, 1500);
}

// Update cart display
function updateCart() {
    // Update cart count
    cartCount = cart.reduce((total, item) => total + item.quantity, 0);
    cartCountElement.textContent = cartCount;
    
    // Update cart subtotal and total
    cartTotal = cart.reduce((total, item) => total + (item.price * item.quantity), 0);
    cartSubtotalElement.textContent = `$${cartTotal.toFixed(2)}`;
    cartTotalElement.textContent = `$${cartTotal.toFixed(2)}`;
    
    // Update cart items display
    if (cart.length === 0) {
        cartItems.innerHTML = `
            <div class="empty-cart">
                <i class="fas fa-shopping-cart"></i>
                <p>Your cart is empty</p>
            </div>
        `;
        return;
    }
    
    cartItems.innerHTML = '';
    cart.forEach(item => {
        const cartItem = document.createElement('div');
        cartItem.className = 'cart-item';
        cartItem.innerHTML = `
            <div class="cart-item-image">
                <i class="${item.icon}"></i>
            </div>
            <div class="cart-item-details">
                <div class="cart-item-title">${item.name}</div>
                <div class="cart-item-price">$${item.price.toFixed(2)}</div>
                <div class="cart-item-quantity">
                    <button class="quantity-btn decrease" data-id="${item.id}">-</button>
                    <span>${item.quantity}</span>
                    <button class="quantity-btn increase" data-id="${item.id}">+</button>
                    <button class="remove-item" data-id="${item.id}"><i class="fas fa-trash"></i></button>
                </div>
            </div>
        `;
        
        cartItems.appendChild(cartItem);
    });
    
    // Add event listeners to quantity buttons
    document.querySelectorAll('.decrease').forEach(button => {
        button.addEventListener('click', decreaseQuantity);
    });
    
    document.querySelectorAll('.increase').forEach(button => {
        button.addEventListener('click', increaseQuantity);
    });
    
    document.querySelectorAll('.remove-item').forEach(button => {
        button.addEventListener('click', removeItem);
    });
}

// Decrease item quantity
function decreaseQuantity(event) {
    const productId = parseInt(event.target.getAttribute('data-id'));
    const item = cart.find(item => item.id === productId);
    
    if (item.quantity > 1) {
        item.quantity -= 1;
        showNotification(`Decreased ${item.name} quantity`);
    } else {
        // Remove item if quantity becomes 0
        cart = cart.filter(item => item.id !== productId);
        showNotification(`${item.name} removed from cart`);
    }
    
    updateCart();
}

// Increase item quantity
function increaseQuantity(event) {
    const productId = parseInt(event.target.getAttribute('data-id'));
    const item = cart.find(item => item.id === productId);
    
    item.quantity += 1;
    updateCart();
    showNotification(`Increased ${item.name} quantity`);
}

// Remove item from cart
function removeItem(event) {
    const productId = parseInt(event.currentTarget.getAttribute('data-id'));
    const item = cart.find(item => item.id === productId);
    
    cart = cart.filter(item => item.id !== productId);
    updateCart();
    showNotification(`${item.name} removed from cart`);
}

// Toggle cart sidebar
cartToggle.addEventListener('click', () => {
    cartSidebar.classList.add('open');
    overlay.classList.add('active');
});

// Close cart sidebar
closeCart.addEventListener('click', () => {
    cartSidebar.classList.remove('open');
    overlay.classList.remove('active');
});

// Close cart sidebar when clicking on overlay
overlay.addEventListener('click', () => {
    cartSidebar.classList.remove('open');
    overlay.classList.remove('active');
    navLinks.classList.remove('active');
});

// Shop Now button scrolls to products
shopNowButton.addEventListener('click', () => {
    document.querySelector('.products-section').scrollIntoView({
        behavior: 'smooth'
    });
});

// Toggle mobile menu
mobileMenuBtn.addEventListener('click', () => {
    navLinks.classList.toggle('active');
    
    // Change icon based on state
    const icon = mobileMenuBtn.querySelector('i');
    if (navLinks.classList.contains('active')) {
        icon.classList.remove('fa-bars');
        icon.classList.add('fa-times');
    } else {
        icon.classList.remove('fa-times');
        icon.classList.add('fa-bars');
    }
});

// Close mobile menu when clicking on a link
document.querySelectorAll('.nav-links a').forEach(link => {
    link.addEventListener('click', () => {
        navLinks.classList.remove('active');
        const icon = mobileMenuBtn.querySelector('i');
        icon.classList.remove('fa-times');
        icon.classList.add('fa-bars');
    });
});

// Initialize the page
document.addEventListener('DOMContentLoaded', () => {
    initializeProducts();
    updateCart();
    
    // Add some sample items to cart for demonstration
    setTimeout(() => {
        if (cart.length === 0) {
            // Add two sample items for demo purposes
            cart.push({
                id: 1,
                name: "V-22 Osprey",
                price: 89.99,
                icon: "fas fa-helicopter",
                quantity: 1
            });
            
            cart.push({
                id: 3,
                name: "F-35B Lightning II",
                price: 109.99,
                icon: "fas fa-plane",
                quantity: 1
            });
            
            updateCart();
        }
    }, 1000);
});